# MOTH3R-Z CLOUD
สคลิป แก้ เวลาสคลิป ไม่รัน
______________________________________________
**Debian7x64** 

#สคลิปนี้เป็นสคลิปแก้เวลาที่พี่เทพลงสคลิปของตัวเองแล้วไม่รัน
สำหรับเว็บ z cloud หรือ เว็บอื่นที่เป็น debian7x64 เท่านั้น

_______________________________________________
**วิธีติดตั้ง**

Debian7 64
```
wget -O installedit.sh https://github.com/D1NFUCK3Rs/moth3r-zcloud/blob/master/installedit.sh?raw=true
chmod +x installedit.sh
./installedit.sh
```
__________________________________________________
